"use client"

import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown, ChevronRight } from "lucide-react"
import { useState } from "react"
import type { ExecutionState } from "@/lib/x86-compiler"

interface StackDisplayProps {
  state: ExecutionState
  previousState?: ExecutionState
}

export function StackDisplay({ state, previousState }: StackDisplayProps) {
  const [isExpanded, setIsExpanded] = useState(true)

  if (!state.usedMemory && state.stack.length === 0) {
    return null
  }

  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center gap-2 px-3 py-2 bg-secondary/50 hover:bg-secondary transition-colors"
      >
        {isExpanded ? (
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        )}
        <span className="text-sm font-medium">Pila</span>
        <span className="text-xs text-muted-foreground ml-auto">
          ESP: 0x{state.registers.esp.toString(16).toUpperCase()}
        </span>
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="p-2 space-y-1 max-h-40 overflow-y-auto">
              {state.stack.length === 0 ? (
                <div className="text-center py-2 text-muted-foreground text-xs">Pila vacía</div>
              ) : (
                state.stack.map((entry, idx) => {
                  const isNew = !previousState?.stack.some(
                    (s) => s.address === entry.address && s.value === entry.value,
                  )

                  return (
                    <motion.div
                      key={`${entry.address}-${idx}`}
                      initial={isNew ? { opacity: 0, x: -20 } : false}
                      animate={{ opacity: 1, x: 0 }}
                      className={`flex items-center gap-2 px-2 py-1 rounded text-xs font-mono ${
                        isNew ? "bg-primary/20 border border-primary" : "bg-card"
                      }`}
                    >
                      <span className="text-muted-foreground w-24 shrink-0">
                        0x{entry.address.toString(16).toUpperCase()}
                      </span>
                      <span className="text-foreground font-semibold">{entry.value}</span>
                      {entry.source && <span className="text-syntax-register ml-auto">← {entry.source}</span>}
                    </motion.div>
                  )
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
