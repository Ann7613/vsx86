"use client"

import { motion } from "framer-motion"
import { ArrowRight, Lightbulb } from "lucide-react"
import type { ExecutionStep } from "@/lib/x86-compiler"

interface InstructionPreviewProps {
  step: ExecutionStep | null
  isComplete: boolean
}

export function InstructionPreview({ step, isComplete }: InstructionPreviewProps) {
  if (isComplete) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/30 rounded-xl p-6 text-center"
      >
        <div className="text-4xl mb-3">🎉</div>
        <h3 className="text-xl font-bold text-foreground mb-2">¡Ejecución Completa!</h3>
        <p className="text-muted-foreground">Todas las instrucciones han sido ejecutadas exitosamente.</p>
      </motion.div>
    )
  }

  if (!step) {
    return (
      <div className="bg-card border border-border rounded-xl p-6 text-center">
        <div className="text-muted-foreground">Compila el código para ver la ejecución paso a paso</div>
      </div>
    )
  }

  return (
    <motion.div
      key={step.instruction.line}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.2 }}
      className="bg-card border border-border rounded-xl overflow-hidden"
    >
      {/* Current instruction */}
      <div className="p-4 bg-gradient-to-r from-primary/10 to-transparent border-b border-border">
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
          <span className="px-2 py-0.5 bg-primary/20 text-primary rounded font-medium">
            Línea {step.instruction.line}
          </span>
          <ArrowRight className="w-3 h-3" />
          <span>Próxima instrucción</span>
        </div>
        <code className="text-lg font-mono font-semibold text-foreground">{step.instruction.original}</code>
      </div>

      {/* Explanation */}
      <div className="p-4 border-b border-border">
        <div className="flex items-start gap-2">
          <Lightbulb className="w-4 h-4 text-accent mt-0.5 shrink-0" />
          <p className="text-sm text-muted-foreground leading-relaxed">{step.explanation}</p>
        </div>
      </div>

      {/* Changes preview */}
      {step.changes.length > 0 && (
        <div className="p-4 bg-secondary/30">
          <div className="text-xs font-medium text-muted-foreground mb-2">Cambios:</div>
          <div className="space-y-1">
            {step.changes.map((change, idx) => (
              <div key={idx} className="flex items-center gap-2 text-sm font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                <span className="text-foreground">{change}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  )
}
