"use client"

import { motion } from "framer-motion"
import type { ExecutionState } from "@/lib/x86-compiler"

interface FlagsDisplayProps {
  state: ExecutionState
  previousState?: ExecutionState
}

const FLAG_NAMES: Record<string, string> = {
  ZF: "Zero",
  SF: "Sign",
  CF: "Carry",
  OF: "Overflow",
}

export function FlagsDisplay({ state, previousState }: FlagsDisplayProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {Object.entries(state.flags).map(([flag, value]) => {
        const prevValue = previousState?.flags[flag]
        const changed = previousState && prevValue !== value

        return (
          <motion.div
            key={flag}
            animate={{
              scale: changed ? [1, 1.1, 1] : 1,
            }}
            transition={{ duration: 0.2 }}
            className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-mono ${
              value
                ? "bg-primary/20 text-primary border border-primary"
                : "bg-secondary text-muted-foreground border border-border"
            } ${changed ? "ring-2 ring-primary ring-offset-1 ring-offset-background" : ""}`}
          >
            <span className="font-bold">{flag}</span>
            <span className="text-[10px] opacity-70">{FLAG_NAMES[flag]}</span>
            <span className="ml-1 font-bold">{value ? "1" : "0"}</span>
          </motion.div>
        )
      })}
    </div>
  )
}
