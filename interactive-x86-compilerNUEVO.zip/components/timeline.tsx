"use client"

import { motion } from "framer-motion"
import { Play, Pause, SkipBack, SkipForward, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { ExecutionStep } from "@/lib/x86-compiler"

interface TimelineProps {
  steps: ExecutionStep[]
  currentStep: number
  isPlaying: boolean
  onStepChange: (step: number) => void
  onPlayPause: () => void
  onReset: () => void
}

export function Timeline({ steps, currentStep, isPlaying, onStepChange, onPlayPause, onReset }: TimelineProps) {
  const progress = steps.length > 0 ? ((currentStep + 1) / steps.length) * 100 : 0

  return (
    <div className="bg-card border border-border rounded-xl p-4 space-y-4">
      {/* Progress bar */}
      <div className="relative">
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-primary to-accent"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        {/* Step markers */}
        <div className="absolute inset-x-0 top-0 flex justify-between">
          {steps.map((_, idx) => (
            <button
              key={idx}
              onClick={() => onStepChange(idx)}
              className={`w-3 h-3 -mt-0.5 rounded-full transition-all ${
                idx === currentStep
                  ? "bg-primary scale-125 ring-2 ring-primary/50"
                  : idx < currentStep
                    ? "bg-primary/60"
                    : "bg-secondary border border-border"
              }`}
              title={`Paso ${idx + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={onReset}
          disabled={currentStep === 0}
          className="h-9 w-9 bg-transparent"
        >
          <RotateCcw className="w-4 h-4" />
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={() => onStepChange(Math.max(0, currentStep - 1))}
          disabled={currentStep === 0}
          className="h-9 w-9"
        >
          <SkipBack className="w-4 h-4" />
        </Button>

        <Button
          variant="default"
          size="icon"
          onClick={onPlayPause}
          disabled={steps.length === 0}
          className="h-11 w-11 rounded-full"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={() => onStepChange(Math.min(steps.length - 1, currentStep + 1))}
          disabled={currentStep >= steps.length - 1}
          className="h-9 w-9"
        >
          <SkipForward className="w-4 h-4" />
        </Button>

        <div className="ml-4 text-sm font-medium text-muted-foreground">
          {steps.length > 0 ? (
            <>
              Paso <span className="text-foreground">{currentStep + 1}</span> de{" "}
              <span className="text-foreground">{steps.length}</span>
            </>
          ) : (
            "Sin instrucciones"
          )}
        </div>
      </div>
    </div>
  )
}
