"use client"

import { useRef, useEffect } from "react"

interface CodeEditorProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}

export function CodeEditor({ value, onChange, placeholder }: CodeEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const highlightRef = useRef<HTMLDivElement>(null)

  const highlightCode = (code: string): string => {
    return code
      .split("\n")
      .map((line) => {
        // Comments
        if (line.trim().startsWith(";") || line.trim().startsWith("//")) {
          return `<span class="text-syntax-comment">${escapeHtml(line)}</span>`
        }

        let highlighted = escapeHtml(line)

        // Labels (end with :)
        highlighted = highlighted.replace(/^(\s*)(\w+:)/g, '$1<span class="text-syntax-label">$2</span>')

        // Keywords/opcodes
        const keywords = [
          "mov",
          "add",
          "sub",
          "mul",
          "imul",
          "div",
          "idiv",
          "inc",
          "dec",
          "and",
          "or",
          "xor",
          "not",
          "neg",
          "shl",
          "shr",
          "sal",
          "sar",
          "push",
          "pop",
          "call",
          "ret",
          "jmp",
          "je",
          "jne",
          "jz",
          "jnz",
          "jg",
          "jl",
          "jge",
          "jle",
          "jng",
          "jnl",
          "jnge",
          "jnle",
          "cmp",
          "test",
          "lea",
          "xchg",
          "nop",
          "cdq",
        ]
        keywords.forEach((kw) => {
          const regex = new RegExp(`\\b(${kw})\\b`, "gi")
          highlighted = highlighted.replace(regex, '<span class="text-syntax-keyword">$1</span>')
        })

        // Registers
        const registers = [
          "eax",
          "ebx",
          "ecx",
          "edx",
          "esi",
          "edi",
          "ebp",
          "esp",
          "ax",
          "bx",
          "cx",
          "dx",
          "si",
          "di",
          "bp",
          "sp",
          "al",
          "bl",
          "cl",
          "dl",
          "ah",
          "bh",
          "ch",
          "dh",
        ]
        registers.forEach((reg) => {
          const regex = new RegExp(`\\b(${reg})\\b`, "gi")
          highlighted = highlighted.replace(regex, '<span class="text-syntax-register">$1</span>')
        })

        // Numbers (hex and decimal)
        highlighted = highlighted.replace(
          /\b(0x[0-9a-fA-F]+|[0-9]+h?)\b/g,
          '<span class="text-syntax-number">$1</span>',
        )

        // Inline comments
        const commentIndex = highlighted.indexOf(";")
        if (commentIndex !== -1) {
          const beforeComment = highlighted.slice(0, commentIndex)
          const comment = highlighted.slice(commentIndex)
          highlighted = beforeComment + `<span class="text-syntax-comment">${comment}</span>`
        }

        return highlighted
      })
      .join("\n")
  }

  const escapeHtml = (text: string): string => {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  }

  const syncScroll = () => {
    if (textareaRef.current && highlightRef.current) {
      highlightRef.current.scrollTop = textareaRef.current.scrollTop
      highlightRef.current.scrollLeft = textareaRef.current.scrollLeft
    }
  }

  useEffect(() => {
    const textarea = textareaRef.current
    if (textarea) {
      textarea.addEventListener("scroll", syncScroll)
      return () => textarea.removeEventListener("scroll", syncScroll)
    }
  }, [])

  return (
    <div className="relative h-full font-mono text-sm">
      {/* Highlighted code layer */}
      <div
        ref={highlightRef}
        className="absolute inset-0 p-4 overflow-auto whitespace-pre pointer-events-none"
        dangerouslySetInnerHTML={{
          __html: highlightCode(value) || `<span class="text-muted-foreground">${placeholder || ""}</span>`,
        }}
      />
      {/* Textarea layer */}
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onScroll={syncScroll}
        className="absolute inset-0 w-full h-full p-4 bg-transparent text-transparent caret-foreground resize-none outline-none"
        spellCheck={false}
        placeholder={placeholder}
      />
    </div>
  )
}
