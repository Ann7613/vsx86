"use client"

import { motion, AnimatePresence } from "framer-motion"
import type { ExecutionState } from "@/lib/x86-compiler"

interface RegisterDisplayProps {
  state: ExecutionState
  previousState?: ExecutionState
}

const REGISTER_COLORS: Record<string, string> = {
  eax: "bg-chart-1/20 border-chart-1",
  ebx: "bg-chart-2/20 border-chart-2",
  ecx: "bg-chart-3/20 border-chart-3",
  edx: "bg-chart-4/20 border-chart-4",
  esi: "bg-chart-5/20 border-chart-5",
  edi: "bg-chart-1/20 border-chart-1",
  ebp: "bg-chart-2/20 border-chart-2",
  esp: "bg-chart-3/20 border-chart-3",
}

export function RegisterDisplay({ state, previousState }: RegisterDisplayProps) {
  const usedRegs = Array.from(state.usedRegisters).filter((r) =>
    ["eax", "ebx", "ecx", "edx", "esi", "edi", "ebp", "esp"].includes(r),
  )

  if (usedRegs.length === 0) {
    return <div className="text-center py-4 text-muted-foreground text-sm">No hay registros en uso</div>
  }

  return (
    <div className="grid grid-cols-2 gap-2">
      <AnimatePresence mode="popLayout">
        {usedRegs.sort().map((reg) => {
          const value = state.registers[reg]
          const prevValue = previousState?.registers[reg]
          const changed = previousState && prevValue !== value
          const colorClass = REGISTER_COLORS[reg] || "bg-secondary border-border"

          return (
            <motion.div
              key={reg}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{
                opacity: 1,
                scale: 1,
                boxShadow: changed ? "0 0 12px rgba(0, 255, 180, 0.5)" : "none",
              }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.2 }}
              className={`relative p-2 rounded-lg border-2 ${colorClass} ${changed ? "ring-2 ring-primary" : ""}`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-bold text-xs uppercase tracking-wide text-foreground">{reg}</span>
                <span className="font-mono text-xs text-muted-foreground">
                  0x{value.toString(16).toUpperCase().padStart(8, "0")}
                </span>
              </div>
              <div className="mt-1 font-mono text-lg font-semibold text-foreground">{value}</div>
              {changed && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-primary"
                />
              )}
            </motion.div>
          )
        })}
      </AnimatePresence>
    </div>
  )
}
