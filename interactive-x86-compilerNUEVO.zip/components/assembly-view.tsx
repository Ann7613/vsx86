"use client"

import { motion } from "framer-motion"
import type { Instruction } from "@/lib/x86-compiler"

interface AssemblyViewProps {
  instructions: Instruction[]
  currentLine: number
}

export function AssemblyView({ instructions, currentLine }: AssemblyViewProps) {
  if (instructions.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
        El assembly compilado aparecerá aquí
      </div>
    )
  }

  return (
    <div className="font-mono text-sm space-y-0.5 p-3">
      {instructions.map((inst, idx) => {
        const isCurrent = idx === currentLine
        const isPast = idx < currentLine

        return (
          <motion.div
            key={inst.line}
            initial={false}
            animate={{
              backgroundColor: isCurrent ? "rgba(0, 255, 180, 0.15)" : "transparent",
            }}
            className={`flex items-center gap-3 px-2 py-1 rounded ${
              isCurrent ? "border-l-2 border-primary" : isPast ? "opacity-50" : ""
            }`}
          >
            {/* Line number */}
            <span className="w-6 text-right text-muted-foreground text-xs shrink-0">{inst.line}</span>

            {/* Instruction */}
            <span className={`flex-1 ${isCurrent ? "text-foreground font-semibold" : "text-foreground"}`}>
              <span className="text-syntax-keyword">{inst.opcode}</span>
              {inst.operands.length > 0 && (
                <span className="ml-2">
                  {inst.operands.map((op, opIdx) => (
                    <span key={opIdx}>
                      {opIdx > 0 && <span className="text-muted-foreground">, </span>}
                      <span className={getOperandColor(op)}>{op}</span>
                    </span>
                  ))}
                </span>
              )}
            </span>

            {/* Current indicator */}
            {isCurrent && <motion.div layoutId="current-instruction" className="w-2 h-2 rounded-full bg-primary" />}
          </motion.div>
        )
      })}
    </div>
  )
}

function getOperandColor(operand: string): string {
  const lower = operand.toLowerCase()

  // Registers
  const registers = [
    "eax",
    "ebx",
    "ecx",
    "edx",
    "esi",
    "edi",
    "ebp",
    "esp",
    "ax",
    "bx",
    "cx",
    "dx",
    "si",
    "di",
    "bp",
    "sp",
    "al",
    "bl",
    "cl",
    "dl",
    "ah",
    "bh",
    "ch",
    "dh",
  ]
  if (registers.includes(lower)) {
    return "text-syntax-register"
  }

  // Numbers
  if (/^(0x[0-9a-f]+|[0-9]+h?)$/i.test(lower)) {
    return "text-syntax-number"
  }

  // Memory references
  if (lower.startsWith("[")) {
    return "text-syntax-string"
  }

  return "text-foreground"
}
