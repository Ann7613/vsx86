// Types for the x86 compiler and virtual machine

export interface Register {
  name: string
  value: number
  size: 32 | 16 | 8
  displayName: string
}

export interface MemoryCell {
  address: number
  value: number
  label?: string
}

export interface StackEntry {
  address: number
  value: number
  source?: string
}

export interface ExecutionState {
  registers: Record<string, number>
  stack: StackEntry[]
  memory: MemoryCell[]
  flags: Record<string, boolean>
  ip: number // instruction pointer (current line)
  usedRegisters: Set<string>
  usedMemory: boolean
}

export interface Instruction {
  line: number
  original: string
  opcode: string
  operands: string[]
  explanation: string
}

export interface CompilationResult {
  success: boolean
  instructions: Instruction[]
  errors: string[]
  initialState: ExecutionState
}

export interface ExecutionStep {
  instruction: Instruction
  beforeState: ExecutionState
  afterState: ExecutionState
  explanation: string
  changes: string[]
}

// Register definitions
const REGISTERS_32 = ["eax", "ebx", "ecx", "edx", "esi", "edi", "ebp", "esp"]
const REGISTERS_16 = ["ax", "bx", "cx", "dx", "si", "di", "bp", "sp"]
const REGISTERS_8_HIGH = ["ah", "bh", "ch", "dh"]
const REGISTERS_8_LOW = ["al", "bl", "cl", "dl"]

const ALL_REGISTERS = [...REGISTERS_32, ...REGISTERS_16, ...REGISTERS_8_HIGH, ...REGISTERS_8_LOW]

// Initial state generator
function createInitialState(): ExecutionState {
  const registers: Record<string, number> = {}
  ALL_REGISTERS.forEach((reg) => {
    registers[reg] = 0
  })
  // ESP starts at a higher address (simulating stack base)
  registers["esp"] = 0x7fff0000

  return {
    registers,
    stack: [],
    memory: [],
    flags: {
      ZF: false, // Zero Flag
      SF: false, // Sign Flag
      CF: false, // Carry Flag
      OF: false, // Overflow Flag
    },
    ip: 0,
    usedRegisters: new Set(),
    usedMemory: false,
  }
}

// Clone state deeply
function cloneState(state: ExecutionState): ExecutionState {
  return {
    registers: { ...state.registers },
    stack: state.stack.map((s) => ({ ...s })),
    memory: state.memory.map((m) => ({ ...m })),
    flags: { ...state.flags },
    ip: state.ip,
    usedRegisters: new Set(state.usedRegisters),
    usedMemory: state.usedMemory,
  }
}

// Parse operand value
function parseOperand(operand: string, state: ExecutionState): number {
  operand = operand.trim().toLowerCase()

  // Check if it's a register
  if (ALL_REGISTERS.includes(operand)) {
    return getRegisterValue(operand, state)
  }

  // Check if it's a hex number
  if (operand.startsWith("0x") || operand.endsWith("h")) {
    const hex = operand.startsWith("0x") ? operand.slice(2) : operand.slice(0, -1)
    return Number.parseInt(hex, 16)
  }

  // Check if it's a decimal number
  if (/^-?\d+$/.test(operand)) {
    return Number.parseInt(operand, 10)
  }

  // Memory reference [address] or [reg+offset]
  if (operand.startsWith("[") && operand.endsWith("]")) {
    const inner = operand.slice(1, -1)
    // Simple register reference like [eax]
    if (ALL_REGISTERS.includes(inner)) {
      const addr = getRegisterValue(inner, state)
      return getMemoryValue(addr, state)
    }
    // Register + offset like [ebp+4] or [ebp-4]
    const match = inner.match(/(\w+)\s*([+-])\s*(\d+)/)
    if (match) {
      const [, reg, op, offset] = match
      const base = getRegisterValue(reg, state)
      const off = Number.parseInt(offset)
      const addr = op === "+" ? base + off : base - off
      return getMemoryValue(addr, state)
    }
  }

  return 0
}

function getRegisterValue(reg: string, state: ExecutionState): number {
  reg = reg.toLowerCase()

  // 32-bit registers
  if (REGISTERS_32.includes(reg)) {
    return state.registers[reg] >>> 0
  }

  // 16-bit registers (lower 16 bits of corresponding 32-bit)
  if (REGISTERS_16.includes(reg)) {
    const map: Record<string, string> = {
      ax: "eax",
      bx: "ebx",
      cx: "ecx",
      dx: "edx",
      si: "esi",
      di: "edi",
      bp: "ebp",
      sp: "esp",
    }
    return (state.registers[map[reg]] & 0xffff) >>> 0
  }

  // 8-bit low registers
  if (REGISTERS_8_LOW.includes(reg)) {
    const map: Record<string, string> = { al: "eax", bl: "ebx", cl: "ecx", dl: "edx" }
    return (state.registers[map[reg]] & 0xff) >>> 0
  }

  // 8-bit high registers
  if (REGISTERS_8_HIGH.includes(reg)) {
    const map: Record<string, string> = { ah: "eax", bh: "ebx", ch: "ecx", dh: "edx" }
    return ((state.registers[map[reg]] >> 8) & 0xff) >>> 0
  }

  return 0
}

function setRegisterValue(reg: string, value: number, state: ExecutionState): void {
  reg = reg.toLowerCase()
  state.usedRegisters.add(reg)

  // Also track the parent register
  const parentMap: Record<string, string> = {
    ax: "eax",
    bx: "ebx",
    cx: "ecx",
    dx: "edx",
    si: "esi",
    di: "edi",
    bp: "ebp",
    sp: "esp",
    al: "eax",
    bl: "ebx",
    cl: "ecx",
    dl: "edx",
    ah: "eax",
    bh: "ebx",
    ch: "ecx",
    dh: "edx",
  }
  if (parentMap[reg]) {
    state.usedRegisters.add(parentMap[reg])
  }

  if (REGISTERS_32.includes(reg)) {
    state.registers[reg] = value >>> 0
  } else if (REGISTERS_16.includes(reg)) {
    const parent = parentMap[reg]
    state.registers[parent] = (state.registers[parent] & 0xffff0000) | (value & 0xffff)
  } else if (REGISTERS_8_LOW.includes(reg)) {
    const parent = parentMap[reg]
    state.registers[parent] = (state.registers[parent] & 0xffffff00) | (value & 0xff)
  } else if (REGISTERS_8_HIGH.includes(reg)) {
    const parent = parentMap[reg]
    state.registers[parent] = (state.registers[parent] & 0xffff00ff) | ((value & 0xff) << 8)
  }
}

function getMemoryValue(address: number, state: ExecutionState): number {
  const cell = state.memory.find((m) => m.address === address)
  return cell ? cell.value : 0
}

function setMemoryValue(address: number, value: number, state: ExecutionState, label?: string): void {
  state.usedMemory = true
  const existing = state.memory.find((m) => m.address === address)
  if (existing) {
    existing.value = value >>> 0
  } else {
    state.memory.push({ address, value: value >>> 0, label })
  }
}

function updateFlags(result: number, state: ExecutionState): void {
  state.flags.ZF = (result & 0xffffffff) === 0
  state.flags.SF = (result & 0x80000000) !== 0
}

// Compile source code to instructions
export function compile(source: string): CompilationResult {
  const lines = source.split("\n")
  const instructions: Instruction[] = []
  const errors: string[] = []
  const initialState = createInitialState()

  lines.forEach((line, index) => {
    const trimmed = line.trim()

    // Skip empty lines and comments
    if (!trimmed || trimmed.startsWith(";") || trimmed.startsWith("//")) {
      return
    }

    // Remove inline comments
    const withoutComment = trimmed.split(";")[0].trim()
    if (!withoutComment) return

    // Skip labels for now (they end with :)
    if (withoutComment.endsWith(":")) {
      return
    }

    // Parse instruction
    const parts = withoutComment.split(/[\s,]+/).filter(Boolean)
    if (parts.length === 0) return

    const opcode = parts[0].toLowerCase()
    const operands = parts.slice(1)

    const instruction: Instruction = {
      line: index + 1,
      original: trimmed,
      opcode,
      operands,
      explanation: getInstructionExplanation(opcode, operands),
    }

    // Mark used registers in initial state
    operands.forEach((op) => {
      const clean = op.toLowerCase().replace(/[[\]]/g, "").split(/[+-]/)[0]
      if (ALL_REGISTERS.includes(clean)) {
        initialState.usedRegisters.add(clean)
        // Track parent register
        const parentMap: Record<string, string> = {
          ax: "eax",
          bx: "ebx",
          cx: "ecx",
          dx: "edx",
          si: "esi",
          di: "edi",
          bp: "ebp",
          sp: "esp",
          al: "eax",
          bl: "ebx",
          cl: "ecx",
          dl: "edx",
          ah: "eax",
          bh: "ebx",
          ch: "ecx",
          dh: "edx",
        }
        if (parentMap[clean]) {
          initialState.usedRegisters.add(parentMap[clean])
        }
      }
    })

    // Check for memory operations
    if (
      ["push", "pop", "call", "ret"].includes(opcode) ||
      operands.some((op) => op.includes("[") && op.includes("]"))
    ) {
      initialState.usedMemory = true
    }

    instructions.push(instruction)
  })

  return {
    success: errors.length === 0,
    instructions,
    errors,
    initialState,
  }
}

function getInstructionExplanation(opcode: string, operands: string[]): string {
  const ops = operands.map((o) => o.toUpperCase())

  switch (opcode) {
    case "mov":
      return `Copia el valor de ${ops[1]} a ${ops[0]}`
    case "add":
      return `Suma ${ops[1]} a ${ops[0]} y guarda el resultado en ${ops[0]}`
    case "sub":
      return `Resta ${ops[1]} de ${ops[0]} y guarda el resultado en ${ops[0]}`
    case "mul":
      return `Multiplica EAX por ${ops[0]}, resultado en EDX:EAX`
    case "imul":
      if (ops.length === 1) return `Multiplicación con signo de EAX por ${ops[0]}`
      if (ops.length === 2) return `Multiplica ${ops[0]} por ${ops[1]}, resultado en ${ops[0]}`
      return `Multiplica ${ops[1]} por ${ops[2]}, resultado en ${ops[0]}`
    case "div":
      return `Divide EDX:EAX entre ${ops[0]}, cociente en EAX, resto en EDX`
    case "idiv":
      return `División con signo de EDX:EAX entre ${ops[0]}`
    case "inc":
      return `Incrementa ${ops[0]} en 1`
    case "dec":
      return `Decrementa ${ops[0]} en 1`
    case "and":
      return `Operación AND bit a bit: ${ops[0]} = ${ops[0]} AND ${ops[1]}`
    case "or":
      return `Operación OR bit a bit: ${ops[0]} = ${ops[0]} OR ${ops[1]}`
    case "xor":
      return `Operación XOR bit a bit: ${ops[0]} = ${ops[0]} XOR ${ops[1]}`
    case "not":
      return `Invierte todos los bits de ${ops[0]}`
    case "neg":
      return `Niega ${ops[0]} (complemento a dos)`
    case "shl":
    case "sal":
      return `Desplaza ${ops[0]} a la izquierda ${ops[1]} posiciones`
    case "shr":
      return `Desplaza ${ops[0]} a la derecha ${ops[1]} posiciones (sin signo)`
    case "sar":
      return `Desplaza ${ops[0]} a la derecha ${ops[1]} posiciones (con signo)`
    case "push":
      return `Empuja ${ops[0]} a la pila (ESP -= 4, [ESP] = ${ops[0]})`
    case "pop":
      return `Saca el valor de la pila a ${ops[0]} (${ops[0]} = [ESP], ESP += 4)`
    case "cmp":
      return `Compara ${ops[0]} con ${ops[1]} (actualiza flags sin guardar resultado)`
    case "test":
      return `Prueba AND entre ${ops[0]} y ${ops[1]} (actualiza flags sin guardar)`
    case "jmp":
      return `Salta incondicionalmente a ${ops[0]}`
    case "je":
    case "jz":
      return `Salta a ${ops[0]} si igual (ZF=1)`
    case "jne":
    case "jnz":
      return `Salta a ${ops[0]} si no igual (ZF=0)`
    case "jg":
    case "jnle":
      return `Salta a ${ops[0]} si mayor (con signo)`
    case "jl":
    case "jnge":
      return `Salta a ${ops[0]} si menor (con signo)`
    case "jge":
    case "jnl":
      return `Salta a ${ops[0]} si mayor o igual (con signo)`
    case "jle":
    case "jng":
      return `Salta a ${ops[0]} si menor o igual (con signo)`
    case "call":
      return `Llama a la subrutina ${ops[0]} (guarda dirección de retorno en pila)`
    case "ret":
      return `Retorna de subrutina (saca dirección de retorno de pila)`
    case "nop":
      return `No hace nada (No Operation)`
    case "lea":
      return `Carga la dirección efectiva de ${ops[1]} en ${ops[0]}`
    case "xchg":
      return `Intercambia los valores de ${ops[0]} y ${ops[1]}`
    case "cdq":
      return `Extiende el signo de EAX a EDX:EAX`
    default:
      return `Ejecuta ${opcode.toUpperCase()} con ${ops.join(", ") || "sin operandos"}`
  }
}

// Execute a single instruction
export function executeInstruction(
  instruction: Instruction,
  state: ExecutionState,
): { newState: ExecutionState; changes: string[] } {
  const newState = cloneState(state)
  const changes: string[] = []
  const { opcode, operands } = instruction

  switch (opcode) {
    case "mov": {
      const dest = operands[0].toLowerCase()
      const srcValue = parseOperand(operands[1], state)

      if (dest.startsWith("[")) {
        // Memory destination
        const inner = dest.slice(1, -1)
        let addr: number
        if (ALL_REGISTERS.includes(inner)) {
          addr = getRegisterValue(inner, state)
        } else {
          addr = parseOperand(inner, state)
        }
        setMemoryValue(addr, srcValue, newState)
        changes.push(`Memoria[0x${addr.toString(16).toUpperCase()}] = ${srcValue}`)
      } else {
        const oldValue = getRegisterValue(dest, state)
        setRegisterValue(dest, srcValue, newState)
        changes.push(`${dest.toUpperCase()}: ${oldValue} → ${srcValue}`)
      }
      break
    }

    case "add": {
      const dest = operands[0].toLowerCase()
      const destValue = parseOperand(dest, state)
      const srcValue = parseOperand(operands[1], state)
      const result = destValue + srcValue
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      changes.push(`${dest.toUpperCase()}: ${destValue} + ${srcValue} = ${result & 0xffffffff}`)
      break
    }

    case "sub": {
      const dest = operands[0].toLowerCase()
      const destValue = parseOperand(dest, state)
      const srcValue = parseOperand(operands[1], state)
      const result = destValue - srcValue
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      newState.flags.CF = destValue < srcValue
      changes.push(`${dest.toUpperCase()}: ${destValue} - ${srcValue} = ${result & 0xffffffff}`)
      break
    }

    case "mul": {
      const srcValue = parseOperand(operands[0], state)
      const eaxValue = getRegisterValue("eax", state)
      const result = BigInt(eaxValue) * BigInt(srcValue)
      const low = Number(result & BigInt(0xffffffff))
      const high = Number((result >> BigInt(32)) & BigInt(0xffffffff))
      setRegisterValue("eax", low, newState)
      setRegisterValue("edx", high, newState)
      newState.usedRegisters.add("eax")
      newState.usedRegisters.add("edx")
      changes.push(`EAX * ${srcValue} = EDX:EAX (${high}:${low})`)
      break
    }

    case "imul": {
      if (operands.length === 1) {
        const srcValue = parseOperand(operands[0], state)
        const eaxValue = getRegisterValue("eax", state)
        const result = (eaxValue | 0) * (srcValue | 0)
        setRegisterValue("eax", result & 0xffffffff, newState)
        changes.push(`EAX * ${srcValue} = ${result & 0xffffffff}`)
      } else if (operands.length === 2) {
        const dest = operands[0].toLowerCase()
        const srcValue = parseOperand(operands[1], state)
        const destValue = parseOperand(dest, state)
        const result = (destValue | 0) * (srcValue | 0)
        setRegisterValue(dest, result & 0xffffffff, newState)
        changes.push(`${dest.toUpperCase()} * ${srcValue} = ${result & 0xffffffff}`)
      } else {
        const dest = operands[0].toLowerCase()
        const src1 = parseOperand(operands[1], state)
        const src2 = parseOperand(operands[2], state)
        const result = (src1 | 0) * (src2 | 0)
        setRegisterValue(dest, result & 0xffffffff, newState)
        changes.push(`${src1} * ${src2} = ${result & 0xffffffff} → ${dest.toUpperCase()}`)
      }
      break
    }

    case "div": {
      const divisor = parseOperand(operands[0], state)
      if (divisor === 0) {
        changes.push("¡Error: División por cero!")
        break
      }
      const edx = getRegisterValue("edx", state)
      const eax = getRegisterValue("eax", state)
      const dividend = (BigInt(edx) << BigInt(32)) | BigInt(eax)
      const quotient = Number(dividend / BigInt(divisor)) & 0xffffffff
      const remainder = Number(dividend % BigInt(divisor)) & 0xffffffff
      setRegisterValue("eax", quotient, newState)
      setRegisterValue("edx", remainder, newState)
      newState.usedRegisters.add("eax")
      newState.usedRegisters.add("edx")
      changes.push(`EDX:EAX / ${divisor} = EAX:${quotient}, EDX:${remainder}`)
      break
    }

    case "inc": {
      const dest = operands[0].toLowerCase()
      const value = parseOperand(dest, state)
      const result = value + 1
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      changes.push(`${dest.toUpperCase()}: ${value} + 1 = ${result & 0xffffffff}`)
      break
    }

    case "dec": {
      const dest = operands[0].toLowerCase()
      const value = parseOperand(dest, state)
      const result = value - 1
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      changes.push(`${dest.toUpperCase()}: ${value} - 1 = ${result & 0xffffffff}`)
      break
    }

    case "and": {
      const dest = operands[0].toLowerCase()
      const destValue = parseOperand(dest, state)
      const srcValue = parseOperand(operands[1], state)
      const result = destValue & srcValue
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      changes.push(`${dest.toUpperCase()}: ${destValue} AND ${srcValue} = ${result}`)
      break
    }

    case "or": {
      const dest = operands[0].toLowerCase()
      const destValue = parseOperand(dest, state)
      const srcValue = parseOperand(operands[1], state)
      const result = destValue | srcValue
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      changes.push(`${dest.toUpperCase()}: ${destValue} OR ${srcValue} = ${result}`)
      break
    }

    case "xor": {
      const dest = operands[0].toLowerCase()
      const destValue = parseOperand(dest, state)
      const srcValue = parseOperand(operands[1], state)
      const result = destValue ^ srcValue
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      changes.push(`${dest.toUpperCase()}: ${destValue} XOR ${srcValue} = ${result}`)
      break
    }

    case "not": {
      const dest = operands[0].toLowerCase()
      const value = parseOperand(dest, state)
      const result = ~value >>> 0
      setRegisterValue(dest, result, newState)
      changes.push(`${dest.toUpperCase()}: NOT ${value} = ${result}`)
      break
    }

    case "neg": {
      const dest = operands[0].toLowerCase()
      const value = parseOperand(dest, state)
      const result = -value >>> 0
      setRegisterValue(dest, result, newState)
      updateFlags(result, newState)
      newState.flags.CF = value !== 0
      changes.push(`${dest.toUpperCase()}: -${value} = ${result}`)
      break
    }

    case "shl":
    case "sal": {
      const dest = operands[0].toLowerCase()
      const value = parseOperand(dest, state)
      const shift = parseOperand(operands[1], state)
      const result = (value << shift) >>> 0
      setRegisterValue(dest, result, newState)
      changes.push(`${dest.toUpperCase()}: ${value} << ${shift} = ${result}`)
      break
    }

    case "shr": {
      const dest = operands[0].toLowerCase()
      const value = parseOperand(dest, state)
      const shift = parseOperand(operands[1], state)
      const result = value >>> shift
      setRegisterValue(dest, result, newState)
      changes.push(`${dest.toUpperCase()}: ${value} >>> ${shift} = ${result}`)
      break
    }

    case "sar": {
      const dest = operands[0].toLowerCase()
      const value = parseOperand(dest, state) | 0 // signed
      const shift = parseOperand(operands[1], state)
      const result = (value >> shift) >>> 0
      setRegisterValue(dest, result, newState)
      changes.push(`${dest.toUpperCase()}: ${value} >> ${shift} = ${result}`)
      break
    }

    case "push": {
      const value = parseOperand(operands[0], state)
      const newEsp = (getRegisterValue("esp", state) - 4) >>> 0
      setRegisterValue("esp", newEsp, newState)
      newState.stack.unshift({ address: newEsp, value, source: operands[0].toUpperCase() })
      newState.usedMemory = true
      newState.usedRegisters.add("esp")
      changes.push(`PUSH ${operands[0].toUpperCase()}: ESP = 0x${newEsp.toString(16).toUpperCase()}, [ESP] = ${value}`)
      break
    }

    case "pop": {
      const dest = operands[0].toLowerCase()
      const esp = getRegisterValue("esp", state)
      const value = newState.stack.length > 0 ? newState.stack[0].value : 0
      if (newState.stack.length > 0) {
        newState.stack.shift()
      }
      setRegisterValue(dest, value, newState)
      const newEsp = (esp + 4) >>> 0
      setRegisterValue("esp", newEsp, newState)
      newState.usedRegisters.add("esp")
      changes.push(
        `POP ${dest.toUpperCase()}: ${dest.toUpperCase()} = ${value}, ESP = 0x${newEsp.toString(16).toUpperCase()}`,
      )
      break
    }

    case "cmp": {
      const val1 = parseOperand(operands[0], state)
      const val2 = parseOperand(operands[1], state)
      const result = val1 - val2
      updateFlags(result, newState)
      newState.flags.CF = val1 < val2
      changes.push(
        `CMP: ${val1} - ${val2} = ${result} (ZF=${newState.flags.ZF ? 1 : 0}, SF=${newState.flags.SF ? 1 : 0}, CF=${newState.flags.CF ? 1 : 0})`,
      )
      break
    }

    case "test": {
      const val1 = parseOperand(operands[0], state)
      const val2 = parseOperand(operands[1], state)
      const result = val1 & val2
      updateFlags(result, newState)
      newState.flags.CF = false
      newState.flags.OF = false
      changes.push(`TEST: ${val1} AND ${val2} = ${result} (ZF=${newState.flags.ZF ? 1 : 0})`)
      break
    }

    case "xchg": {
      const op1 = operands[0].toLowerCase()
      const op2 = operands[1].toLowerCase()
      const val1 = parseOperand(op1, state)
      const val2 = parseOperand(op2, state)
      setRegisterValue(op1, val2, newState)
      setRegisterValue(op2, val1, newState)
      changes.push(`XCHG: ${op1.toUpperCase()} ↔ ${op2.toUpperCase()} (${val1} ↔ ${val2})`)
      break
    }

    case "lea": {
      const dest = operands[0].toLowerCase()
      const src = operands[1]
      // For simplicity, just parse the address expression
      if (src.startsWith("[") && src.endsWith("]")) {
        const inner = src.slice(1, -1)
        const match = inner.match(/(\w+)\s*([+-])\s*(\d+)/)
        if (match) {
          const [, reg, op, offset] = match
          const base = getRegisterValue(reg.toLowerCase(), state)
          const off = Number.parseInt(offset)
          const addr = op === "+" ? base + off : base - off
          setRegisterValue(dest, addr >>> 0, newState)
          changes.push(
            `LEA ${dest.toUpperCase()}, ${src}: ${dest.toUpperCase()} = 0x${(addr >>> 0).toString(16).toUpperCase()}`,
          )
        } else if (ALL_REGISTERS.includes(inner.toLowerCase())) {
          const addr = getRegisterValue(inner.toLowerCase(), state)
          setRegisterValue(dest, addr, newState)
          changes.push(
            `LEA ${dest.toUpperCase()}, ${src}: ${dest.toUpperCase()} = 0x${addr.toString(16).toUpperCase()}`,
          )
        }
      }
      break
    }

    case "cdq": {
      const eax = getRegisterValue("eax", state) | 0 // signed
      const edx = eax < 0 ? 0xffffffff : 0
      setRegisterValue("edx", edx, newState)
      newState.usedRegisters.add("edx")
      changes.push(`CDQ: EDX = ${eax < 0 ? "0xFFFFFFFF" : "0x00000000"} (sign extension of EAX)`)
      break
    }

    case "nop":
      changes.push("NOP: No se realizó ninguna operación")
      break

    default:
      changes.push(`Instrucción ${opcode.toUpperCase()} ejecutada`)
  }

  newState.ip = state.ip + 1

  return { newState, changes }
}

// Generate all execution steps
export function generateExecutionSteps(compilation: CompilationResult): ExecutionStep[] {
  const steps: ExecutionStep[] = []
  let currentState = cloneState(compilation.initialState)

  for (const instruction of compilation.instructions) {
    const beforeState = cloneState(currentState)
    const { newState, changes } = executeInstruction(instruction, currentState)

    steps.push({
      instruction,
      beforeState,
      afterState: newState,
      explanation: instruction.explanation,
      changes,
    })

    currentState = newState
  }

  return steps
}
