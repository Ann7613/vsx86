"use client"

import { useState, useEffect, useCallback } from "react"
import { ChevronDown, ChevronRight, Play, Code2, Cpu, Terminal } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { CodeEditor } from "@/components/code-editor"
import { AssemblyView } from "@/components/assembly-view"
import { Timeline } from "@/components/timeline"
import { InstructionPreview } from "@/components/instruction-preview"
import { RegisterDisplay } from "@/components/register-display"
import { StackDisplay } from "@/components/stack-display"
import { FlagsDisplay } from "@/components/flags-display"
import { compile, generateExecutionSteps, type CompilationResult, type ExecutionStep } from "@/lib/x86-compiler"

const EXAMPLE_CODE = `; Ejemplo: Calcular factorial de 5
mov eax, 5      ; n = 5
mov ebx, 1      ; resultado = 1

; Loop de multiplicación
imul ebx, eax   ; resultado *= n
dec eax         ; n--
cmp eax, 1      ; comparar n con 1

; Guardar resultado en la pila
push ebx        ; guardar resultado
mov ecx, ebx    ; copiar a ecx

; Operaciones adicionales
add ecx, 10     ; sumar 10
xor edx, edx    ; limpiar edx
mov edx, ecx    ; copiar resultado
`

export default function X86Visualizer() {
  const [sourceCode, setSourceCode] = useState(EXAMPLE_CODE)
  const [isSourceExpanded, setIsSourceExpanded] = useState(true)
  const [compilation, setCompilation] = useState<CompilationResult | null>(null)
  const [steps, setSteps] = useState<ExecutionStep[]>([])
  const [currentStep, setCurrentStep] = useState(-1)
  const [isPlaying, setIsPlaying] = useState(false)

  const handleCompile = useCallback(() => {
    const result = compile(sourceCode)
    setCompilation(result)

    if (result.success) {
      const executionSteps = generateExecutionSteps(result)
      setSteps(executionSteps)
      setCurrentStep(0)
    }
    setIsPlaying(false)
  }, [sourceCode])

  const handlePlayPause = () => {
    if (currentStep >= steps.length - 1) {
      setCurrentStep(0)
    }
    setIsPlaying(!isPlaying)
  }

  const handleReset = () => {
    setCurrentStep(0)
    setIsPlaying(false)
  }

  // Auto-play effect
  useEffect(() => {
    if (isPlaying && currentStep < steps.length - 1) {
      const timer = setTimeout(() => {
        setCurrentStep((prev) => prev + 1)
      }, 1000)
      return () => clearTimeout(timer)
    } else if (currentStep >= steps.length - 1) {
      setIsPlaying(false)
    }
  }, [isPlaying, currentStep, steps.length])

  const currentState = steps[currentStep]?.afterState || compilation?.initialState
  const previousState = currentStep > 0 ? steps[currentStep - 1]?.afterState : undefined
  const isComplete = currentStep >= steps.length - 1 && steps.length > 0

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-[1800px] mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Cpu className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">x86 Visualizer</h1>
              <p className="text-xs text-muted-foreground">Simulador interactivo de Assembly</p>
            </div>
          </div>

          <Button onClick={handleCompile} className="gap-2">
            <Play className="w-4 h-4" />
            Compilar y Ejecutar
          </Button>
        </div>
      </header>

      <div className="max-w-[1800px] mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Left Column - Code */}
          <div className="space-y-4">
            {/* Source Code (Collapsible) */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <button
                onClick={() => setIsSourceExpanded(!isSourceExpanded)}
                className="w-full flex items-center gap-2 px-4 py-3 bg-secondary/30 hover:bg-secondary/50 transition-colors"
              >
                {isSourceExpanded ? (
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                )}
                <Code2 className="w-4 h-4 text-primary" />
                <span className="font-medium text-sm">Código Fuente</span>
                <span className="text-xs text-muted-foreground ml-auto">
                  {isSourceExpanded ? "Clic para colapsar" : "Clic para expandir"}
                </span>
              </button>

              <AnimatePresence>
                {isSourceExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="h-64 bg-background/50">
                      <CodeEditor
                        value={sourceCode}
                        onChange={setSourceCode}
                        placeholder="Escribe tu código x86 aquí..."
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Assembly Generated */}
            <div className="bg-card border border-border rounded-xl overflow-hidden flex-1">
              <div className="flex items-center gap-2 px-4 py-3 bg-secondary/30 border-b border-border">
                <Terminal className="w-4 h-4 text-accent" />
                <span className="font-medium text-sm">Assembly Compilado</span>
                {compilation && (
                  <span className="text-xs text-muted-foreground ml-auto">
                    {compilation.instructions.length} instrucciones
                  </span>
                )}
              </div>
              <div className="h-48 overflow-auto bg-background/50">
                <AssemblyView instructions={compilation?.instructions || []} currentLine={currentStep} />
              </div>
            </div>
          </div>

          {/* Right Column - Visualization */}
          <div className="space-y-4">
            {/* Execution Preview */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="text-sm font-medium text-foreground">Visualización de Ejecución</span>
              </div>
              <InstructionPreview step={steps[currentStep] || null} isComplete={isComplete} />
            </div>

            {/* Timeline */}
            <Timeline
              steps={steps}
              currentStep={currentStep}
              isPlaying={isPlaying}
              onStepChange={setCurrentStep}
              onPlayPause={handlePlayPause}
              onReset={handleReset}
            />

            {/* Registers & Stack */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Registers */}
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-secondary/30 border-b border-border">
                  <span className="font-medium text-sm">Registros</span>
                </div>
                <div className="p-3">
                  {currentState ? (
                    <RegisterDisplay state={currentState} previousState={previousState} />
                  ) : (
                    <div className="text-center py-4 text-muted-foreground text-sm">Compila para ver los registros</div>
                  )}
                </div>
              </div>

              {/* Stack & Flags */}
              <div className="space-y-4">
                {/* Flags */}
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="px-4 py-3 bg-secondary/30 border-b border-border">
                    <span className="font-medium text-sm">Flags</span>
                  </div>
                  <div className="p-3">
                    {currentState ? (
                      <FlagsDisplay state={currentState} previousState={previousState} />
                    ) : (
                      <div className="text-center py-2 text-muted-foreground text-xs">Sin flags activos</div>
                    )}
                  </div>
                </div>

                {/* Stack */}
                {currentState && <StackDisplay state={currentState} previousState={previousState} />}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
