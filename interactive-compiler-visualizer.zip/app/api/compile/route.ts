import { type NextRequest, NextResponse } from "next/server"

interface CompileRequest {
  sourceCode: string
}

interface CompileResponse {
  assembly: string[]
  sourceLineMap: number[]
  variables: Record<string, string>
  stackLayout: { address: string; value: string }[]
}

/**
 * Backend Compilation Endpoint
 *
 * This endpoint is the integration point between the frontend and the C++ compiler.
 * Architecture for modularity and reusability:
 *
 * 1. CURRENT (Simulation Mode):
 *    - When MINIPROYECTO2025-2 is not yet implemented, this endpoint returns mock data
 *    - The frontend works perfectly with any compiler output
 *
 * 2. INTEGRATION POINT:
 *    - When ready, replace the mock logic with:
 *      a) Write sourceCode to a temporary file
 *      b) Execute the C++ compiler (MINIPROYECTO2025-2)
 *      c) Parse the generated x86 assembly output
 *      d) Extract variable mappings and stack layout
 *      e) Generate sourceLineMap (assembly line -> source line)
 *      f) Return result in CompileResponse format
 *
 * 3. FOR MULTIPLE COMPILERS:
 *    - Keep this endpoint signature unchanged
 *    - Just swap the compiler implementation (MINIPROYECTO2025-2 with another)
 *    - Frontend remains completely reusable
 *
 * NEXT STEPS:
 * - Check MINIPROYECTO2025-2/main.cpp for the compiler entry point
 * - It should read source code and output x86 assembly
 * - Use child_process.spawn() to execute the compiled binary
 * - Parse stdout for assembly instructions
 */

export async function POST(request: NextRequest) {
  try {
    const { sourceCode }: CompileRequest = await request.json()

    if (!sourceCode) {
      return NextResponse.json({ error: "Source code is required" }, { status: 400 })
    }

    // TODO: Replace this with actual C++ compiler integration
    // For now, returning mock data to demonstrate the format

    const mockAssembly = [
      "push rbp",
      "mov rbp, rsp",
      "sub rsp, 16",
      "mov dword [rbp-4], 5    ; x = 5",
      "mov dword [rbp-8], 10   ; y = 10",
      "mov eax, dword [rbp-4]  ; load x",
      "cmp eax, dword [rbp-8]  ; compare x with y",
      "jle .else_label",
      "mov eax, dword [rbp-4]  ; print x",
      "jmp .end_label",
      ".else_label:",
      "mov eax, dword [rbp-8]  ; print y",
      ".end_label:",
      "mov rsp, rbp",
      "pop rbp",
      "ret",
    ]

    // sourceLineMap: Each assembly instruction maps to a source code line
    // Example: assembly[3] (mov dword...) was generated from sourceCode line 3
    const sourceLineMap = [0, 0, 0, 2, 3, 4, 4, 4, 5, 5, 6, 6, 7, 7, 7, 7]

    const response: CompileResponse = {
      assembly: mockAssembly,
      sourceLineMap,
      variables: { x: "5", y: "10" },
      stackLayout: [
        { address: "rbp-4", value: "5" },
        { address: "rbp-8", value: "10" },
      ],
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("[v0] Compilation error:", error)
    return NextResponse.json({ error: "Compilation failed" }, { status: 500 })
  }
}
