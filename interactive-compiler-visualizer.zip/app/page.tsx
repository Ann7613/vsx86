"use client"

import { useState } from "react"
import { EditorPanel } from "@/components/editor-panel"
import { AssemblyPanel } from "@/components/assembly-panel"
import { DebuggerPanel } from "@/components/debugger-panel"
import { ControlPanel } from "@/components/control-panel"

interface CompilationResult {
  assembly: string[]
  sourceLineMap: number[] // Maps assembly line index to source line index
  variables: Record<string, string>
  stackLayout: { address: string; value: string }[]
}

export default function Home() {
  const [sourceCode, setSourceCode] = useState(
    `# Lenguaje compilado a x86
var x: int
var y: int
x = 5
y = 10
if x > y:
    print(x)
else:
    print(y)`,
  )
  const [assembly, setAssembly] = useState<string[]>([])
  const [sourceLineMap, setSourceLineMap] = useState<number[]>([]) // Added mapping between assembly and source lines
  const [executionState, setExecutionState] = useState({
    currentLine: 0,
    registers: {
      rax: "0x0",
      rbx: "0x0",
      rcx: "0x0",
      rdx: "0x0",
      rsi: "0x0",
      rdi: "0x0",
    },
    stack: [] as { address: string; value: string }[],
    variables: {} as Record<string, string>,
    output: [] as string[],
  })
  const [isCompiled, setIsCompiled] = useState(false)
  const [isRunning, setIsRunning] = useState(false)
  const [isCompiling, setIsCompiling] = useState(false)

  const handleCompile = async () => {
    setIsCompiling(true)
    try {
      // The backend is responsible for calling MINIPROYECTO2025-2 and returning the result
      const response = await fetch("/api/compile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceCode }),
      })

      if (!response.ok) {
        throw new Error("Compilation failed")
      }

      const result: CompilationResult = await response.json()

      setAssembly(result.assembly)
      setSourceLineMap(result.sourceLineMap)
      setExecutionState((prev) => ({
        ...prev,
        currentLine: 0,
        variables: result.variables,
        stack: result.stackLayout,
      }))
      setIsCompiled(true)
    } catch (error) {
      console.error("[v0] Compilation error:", error)
      alert("Error during compilation. Check console.")
    } finally {
      setIsCompiling(false)
    }
  }

  const handleStep = () => {
    if (executionState.currentLine < assembly.length - 1) {
      setExecutionState((prev) => ({
        ...prev,
        currentLine: prev.currentLine + 1,
        registers: {
          ...prev.registers,
          rax: Math.random() > 0.5 ? "0x5" : "0xa",
        },
      }))
    }
  }

  const handleBack = () => {
    if (executionState.currentLine > 0) {
      setExecutionState((prev) => ({
        ...prev,
        currentLine: prev.currentLine - 1,
      }))
    }
  }

  const handleRunAll = () => {
    setIsRunning(true)
    setExecutionState((prev) => ({
      ...prev,
      currentLine: assembly.length - 1,
      output: [...prev.output, "Output: 5"],
    }))
    setTimeout(() => setIsRunning(false), 500)
  }

  const handleReset = () => {
    setExecutionState((prev) => ({
      ...prev,
      currentLine: 0,
      registers: {
        rax: "0x0",
        rbx: "0x0",
        rcx: "0x0",
        rdx: "0x0",
        rsi: "0x0",
        rdi: "0x0",
      },
      output: [],
    }))
  }

  const currentSourceLine = sourceLineMap[executionState.currentLine] ?? -1

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-sm">
        <div className="max-w-full px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600">
                <span className="text-lg font-bold text-white">X86</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Nexus Compiler</h1>
                <p className="text-sm text-slate-400">x86 Interactive Debugger</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-500">{isCompiled ? "✓ Compiled" : "Ready to compile"}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-1 overflow-hidden">
        {/* Editor Section - Left */}
        <div className="w-1/3 border-r border-slate-700/50 flex flex-col">
          <EditorPanel
            code={sourceCode}
            onCodeChange={setSourceCode}
            onCompile={handleCompile}
            isCompiling={isCompiling}
            highlightLine={currentSourceLine}
          />
        </div>

        {/* Assembly Section - Center */}
        <div className="w-1/3 border-r border-slate-700/50 flex flex-col">
          <AssemblyPanel assembly={assembly} currentLine={executionState.currentLine} isCompiled={isCompiled} />
        </div>

        {/* Debugger Section - Right */}
        <div className="w-1/3 flex flex-col">
          <DebuggerPanel executionState={executionState} />
        </div>
      </main>

      {/* Control Panel - Bottom */}
      <footer className="border-t border-slate-700/50 bg-slate-900/50 backdrop-blur-sm">
        <ControlPanel
          onStep={handleStep}
          onBack={handleBack}
          onRunAll={handleRunAll}
          onReset={handleReset}
          isCompiled={isCompiled}
          isRunning={isRunning}
          currentLine={executionState.currentLine}
          totalLines={assembly.length}
        />
      </footer>
    </div>
  )
}
