"use client"

import { Button } from "@/components/ui/button"
import { Zap } from "lucide-react"

interface EditorPanelProps {
  code: string
  onCodeChange: (code: string) => void
  onCompile: () => void
  isCompiling: boolean
  highlightLine: number // Added highlighting for current source line
}

export function EditorPanel({ code, onCodeChange, onCompile, isCompiling, highlightLine }: EditorPanelProps) {
  const sourceLines = code.split("\n")

  return (
    <div className="flex flex-col h-full bg-slate-950/50">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-700/30 px-4 py-3">
        <h2 className="text-sm font-semibold text-slate-200">Source Code</h2>
        <Button
          onClick={onCompile}
          disabled={isCompiling}
          size="sm"
          className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border-0 disabled:opacity-50"
        >
          <Zap className="w-4 h-4 mr-2" />
          {isCompiling ? "Compiling..." : "Compile"}
        </Button>
      </div>

      {/* Editor with line highlighting */}
      <div className="flex-1 overflow-hidden flex">
        {/* Line numbers */}
        <div className="bg-slate-900/30 border-r border-slate-700/30 px-2 py-4 text-slate-600 font-mono text-sm overflow-hidden">
          {sourceLines.map((_, index) => (
            <div
              key={index}
              className={`h-6 flex items-center transition-colors ${
                index === highlightLine ? "text-cyan-500 font-semibold bg-cyan-500/10" : ""
              }`}
            >
              {(index + 1).toString().padStart(2, " ")}
            </div>
          ))}
        </div>

        {/* Code with highlighting overlay */}
        <div className="flex-1 overflow-hidden relative">
          {highlightLine >= 0 && highlightLine < sourceLines.length && (
            <div
              className="absolute left-0 right-0 h-6 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-l-2 border-cyan-500 transition-all"
              style={{ top: `${highlightLine * 24 + 16}px` }} // 24px per line (h-6) + padding (py-4 = 16px)
            />
          )}

          <textarea
            value={code}
            onChange={(e) => onCodeChange(e.target.value)}
            className="w-full h-full bg-slate-900 text-slate-100 font-mono text-sm border-0 p-4 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 resize-none"
            placeholder="Escribe tu código aquí..."
            spellCheck="false"
          />
        </div>
      </div>

      {/* Info Footer */}
      <div className="border-t border-slate-700/30 px-4 py-2 text-xs text-slate-500">
        <p>Nexus Language • Total lines: {sourceLines.length}</p>
      </div>
    </div>
  )
}
