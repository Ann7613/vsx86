"use client"

import { Button } from "@/components/ui/button"
import { Play, SkipBack, SkipForward, RotateCcw } from "lucide-react"

interface ControlPanelProps {
  onStep: () => void
  onBack: () => void
  onRunAll: () => void
  onReset: () => void
  isCompiled: boolean
  isRunning: boolean
  currentLine: number
  totalLines: number
}

export function ControlPanel({
  onStep,
  onBack,
  onRunAll,
  onReset,
  isCompiled,
  isRunning,
  currentLine,
  totalLines,
}: ControlPanelProps) {
  return (
    <div className="max-w-full px-6 py-4">
      <div className="flex items-center justify-between gap-4">
        {/* Controls */}
        <div className="flex items-center gap-2">
          <Button
            onClick={onBack}
            disabled={!isCompiled || currentLine === 0}
            size="sm"
            variant="outline"
            className="border-slate-700 hover:bg-slate-800 bg-transparent"
          >
            <SkipBack className="w-4 h-4" />
          </Button>

          <Button
            onClick={onStep}
            disabled={!isCompiled || currentLine === totalLines - 1}
            size="sm"
            className="bg-blue-600 hover:bg-blue-700"
          >
            <SkipForward className="w-4 h-4 mr-2" />
            Step
          </Button>

          <Button
            onClick={onRunAll}
            disabled={!isCompiled}
            size="sm"
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
          >
            <Play className="w-4 h-4 mr-2" />
            Run
          </Button>

          <Button
            onClick={onReset}
            disabled={!isCompiled}
            size="sm"
            variant="outline"
            className="border-slate-700 hover:bg-slate-800 bg-transparent"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        {/* Info */}
        <div className="flex items-center gap-6 text-sm">
          <div className="text-slate-400">
            {isRunning ? (
              <span className="text-cyan-400 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
                Running...
              </span>
            ) : (
              <>
                Line <span className="text-cyan-400 ml-1">{currentLine}</span> / {totalLines}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
