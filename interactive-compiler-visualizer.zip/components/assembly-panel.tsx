"use client"

interface AssemblyPanelProps {
  assembly: string[]
  currentLine: number
  isCompiled: boolean
}

export function AssemblyPanel({ assembly, currentLine, isCompiled }: AssemblyPanelProps) {
  return (
    <div className="flex flex-col h-full bg-slate-950/50">
      {/* Header */}
      <div className="border-b border-slate-700/30 px-4 py-3">
        <h2 className="text-sm font-semibold text-slate-200">x86-64 Assembly</h2>
      </div>

      {/* Assembly Code */}
      <div className="flex-1 overflow-y-auto p-4 space-y-1">
        {!isCompiled ? (
          <div className="flex items-center justify-center h-full text-slate-500">
            <div className="text-center">
              <p className="text-sm">Compile source code to view assembly</p>
            </div>
          </div>
        ) : (
          <div className="space-y-0.5">
            {assembly.map((instruction, index) => (
              <div
                key={index}
                className={`flex items-center gap-3 px-3 py-1.5 rounded transition-colors ${
                  index === currentLine
                    ? "bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-l-2 border-cyan-500 text-cyan-100"
                    : "text-slate-400 hover:bg-slate-800/50"
                } font-mono text-sm`}
              >
                <span className="w-8 text-right text-slate-600">{index.toString().padStart(2, "0")}</span>
                <span className="flex-1">{instruction}</span>
                {index === currentLine && <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
