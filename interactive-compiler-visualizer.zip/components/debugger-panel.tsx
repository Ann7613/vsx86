"use client"

interface ExecutionState {
  currentLine: number
  registers: Record<string, string>
  stack: { address: string; value: string }[]
  variables: Record<string, string>
  output: string[]
}

interface DebuggerPanelProps {
  executionState: ExecutionState
}

export function DebuggerPanel({ executionState }: DebuggerPanelProps) {
  return (
    <div className="flex flex-col h-full bg-slate-950/50 overflow-hidden">
      {/* Tabs */}
      <div className="flex border-b border-slate-700/30">
        <div className="flex-1 px-4 py-3 text-sm font-semibold text-cyan-400 border-b-2 border-cyan-500 bg-slate-900/30">
          State
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto space-y-4 p-4">
        {/* Registers */}
        <div>
          <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Registers</h3>
          <div className="space-y-1 bg-slate-900/50 rounded-lg p-2">
            {Object.entries(executionState.registers).map(([name, value]) => (
              <div
                key={name}
                className="flex justify-between items-center px-2 py-1 rounded text-sm font-mono hover:bg-slate-800/50"
              >
                <span className="text-blue-400">{name}</span>
                <span className="text-slate-300">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Variables */}
        {Object.keys(executionState.variables).length > 0 && (
          <div>
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Variables</h3>
            <div className="space-y-1 bg-slate-900/50 rounded-lg p-2">
              {Object.entries(executionState.variables).map(([name, value]) => (
                <div
                  key={name}
                  className="flex justify-between items-center px-2 py-1 rounded text-sm font-mono hover:bg-slate-800/50"
                >
                  <span className="text-green-400">{name}</span>
                  <span className="text-slate-300">{value}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Stack */}
        {executionState.stack.length > 0 && (
          <div>
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Stack</h3>
            <div className="space-y-1 bg-slate-900/50 rounded-lg p-2">
              {executionState.stack.map((item, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center px-2 py-1 rounded text-sm font-mono hover:bg-slate-800/50"
                >
                  <span className="text-yellow-400">{item.address}</span>
                  <span className="text-slate-300">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Output */}
        {executionState.output.length > 0 && (
          <div>
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Output</h3>
            <div className="bg-slate-900/50 rounded-lg p-2 text-sm space-y-1">
              {executionState.output.map((line, index) => (
                <p key={index} className="text-slate-300 font-mono">
                  {line}
                </p>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
